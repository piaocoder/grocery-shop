---
title: shell
date: 2016-09-01 12:00:00
tags: shell
---

欢迎来到狂想的个人实验室。  
github：[unlessbamboo](https://github.com/unlessbamboo)

## 一，Introduction
### 1.1 环境
shell,bash

### 1.2 知识点
0. 基础命令
1. 过滤解析命令
2. 文件操作命令
3. 网络操作命令


. .. ... ....
