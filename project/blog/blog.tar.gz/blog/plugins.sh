#!/bin/bash - 
#===============================================================================
#
#          FILE: plugins.sh
# 
#         USAGE: ./plugins.sh 
# 
#   DESCRIPTION: 按照hexo的第三方插件，从而自动生成sitemap, rss, 部署到git等。
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 2016年12月05日 23:04
#      REVISION:  ---
#===============================================================================

set -o nounset                              # Treat unset variables as an error


npm install hexo-generator-index --save
if [[ $? != 0 ]];then
    echo "Install hexo-generate-index failed."
    exit -1
fi

npm install hexo-generator-archive --save
if [[ $? != 0 ]];then
    echo "Install hexo-generate-archive failed."
    exit -1
fi

npm install hexo-generator-category --save
if [[ $? != 0 ]];then
    echo "Install hexo-generate-category failed."
    exit -1
fi

npm install hexo-generator-tag --save
if [[ $? != 0 ]];then
    echo "Install hexo-generate-tag failed."
    exit -1
fi

npm install hexo-server --save
if [[ $? != 0 ]];then
    echo "Install hexo-server failed."
    exit -1
fi

npm install hexo-deployer-git --save
if [[ $? != 0 ]];then
    echo "Install hexo-deployer-git failed."
    exit -1
fi

npm install hexo-deployer-heroku --save
if [[ $? != 0 ]];then
    echo "Install hexo-deployer-heroku failed."
    exit -1
fi

npm install hexo-deployer-rsync --save
if [[ $? != 0 ]];then
    echo "Install hexo-deployer-rsync failed."
    exit -1
fi

npm install hexo-deployer-openshift --save
if [[ $? != 0 ]];then
    echo "Install hexo-deployer-openshift failed."
    exit -1
fi

npm install hexo-renderer-marked@0.2 --save
if [[ $? != 0 ]];then
    echo "Install hexo-renderer-marked failed."
    exit -1
fi

npm install hexo-renderer-stylus@0.2 --save
if [[ $? != 0 ]];then
    echo "Install hexo-renderer-stylus failed."
    exit -1
fi

npm install hexo-generator-feed@1 --save
if [[ $? != 0 ]];then
    echo "Install hexo-generator-feed failed."
    exit -1
fi

npm install hexo-generator-sitemap@1 --save
if [[ $? != 0 ]];then
    echo "Install hexo-generator-sitemap failed."
    exit -1
fi


echo "Install third plugins complete."
